import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
const App = () => {
  const [value, setValue] = useState('');
  const backgroundStyle = {
    backgroundColor: '#fff',
    flex: 1,
    marginTop: 80,
  };
  useEffect(() => {
    setTimeout(() => {
      setValue('update 1');
    }, 3000);
    setTimeout(() => {
      setValue('update 2');
    }, 5000);
  }, []);
  return (
    <View style={backgroundStyle}>
    <ColoredView />
  </View>
);
};

const ColoredView = () => {
  const style = { backgroundColor: 'red', padding: 10 };
  return <View style={style} />;
};
export default App;