# C PROGRAMING Language(ANSI_C & C99 standards)

Welcome to the C programming Language Exploration repository! This is my private project and aimed at exploring the 2 firsts standards of the C Language: ANSI C and. The goal is to enhance knowledge in low-level programming and related fields.

## Project Description

This repository is focused on the exploration and learning of C programming language, computer architectures, and related subjects through the Netwide Assembler Compiler NASM and GCC

## Roadmap

Here's our roadmap for what's already been accomplished and what is planned to explore in the future:

### Accomplished
- [x] Structures in C.
- [x] Pointers & MEMORY MANAGEMENT.
- [x] Arrays.
- [x] Unions.
- [x] Files & Recursivity


### In Progress: DATA STRUCTURES IN C
- [ ] DYNAMIC ARRAYS & DYNAMIC LISTS.
    - *LINKED LIST*: SIMPLE LIST | SIMPLE CIRCULAR LIST | SYMETRICAL LIST 
    - *STACKS*
    - *QUEUES*
- [ ] GRAPHS & TREES
    - *GRAPHS*
    - *N-ARY TREES*: CONVERSION TO A BINARY TREE.
    - *BINARY TREES*
    - *BINARY SEARCH TREES*

### Future Goals
- [ ] EXTEND TO CODEVELOPMENT WITH VARIOUS ASSEMBLERS.
- [ ] NETWORK&CRYPTOGRAPHY DEVELOPMENT.
- [ ] GRAPHICAL LANGUAGE AND GPU DEVELOPMENT.
- [ ] OPERATING SYSTEM DEVELOPMENT.
- [ ] EMBEDDED SYSTEM DEVELOPMENT.

