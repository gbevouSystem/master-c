const compteur= document.querySelector<HTMLButtonElement>("#compteur")
let i = 0

const increment = (e: Event) => {
    e.preventDefault()
    i = i + 1
    const span = compteur?.querySelector("span")
    if (span) {
        span.innerText = i.toString()
    }
}

compteur?.addEventListener("click", increment)


//Un objet un petit peu dynamique
/**
 * const user: {firstname: string, [key: string]: string} = {firstname: "John", lastname: "Doe"}
 */


/**
 * LE NARROWING
 */

function printId(id: number | string) {
    if (typeof id === "number") {
        console.log((id * 3).toString());
        
    } else {
        console.log(id)
    }
}