import { createSlice } from '@reduxjs/toolkit'


// Define the initial state using that type
const initialState = {
    accessToken: null,
    isLoggedIn: false,
}

export const authSlice = createSlice({
  name: 'auth',
  // `createSlice` will infer the state type from the `initialState` argument
  initialState,
  reducers: {
    setLoggedIn: (state, action)=>{
        state.isLoggedIn = action.payload.accessToken !== undefined ? true : false;
    },
    setAccessToken: (state, action) => {
        state.accessToken = action.payload.accessToken
    }
  },
})

export const { setLoggedIn, setAccessToken } = authSlice.actions


export default authSlice.reducer