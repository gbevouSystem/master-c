import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AuthProvider from '../hooks/auth';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const {Navigator, Screen} = createNativeStackNavigator()

export default function AppNavigator() {
  return (
    <AuthProvider>
      <NavigationContainer>
        <Navigator>
          <Screen name='' component={} />
          <Screen name='' component={} />
          <Screen name='' component={} />
          <Screen name='' component={} />
        </Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
}