import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { setLoggedIn } from '../store/slices/authSlice'

export const AuthContext = React.createContext()

export default function AuthProvider() {
    const isLoggedIn = useSelector(state => state.root.auth.isLoggedIn)
    const setIsLoggedIn = (payload) => {
        useDispatch(setLoggedIn(payload))
    }
    return (
        <AuthContext.Provider value={{isLoggedIn, setIsLoggedIn}} >
            {children}
        </AuthContext.Provider>
    )
}
