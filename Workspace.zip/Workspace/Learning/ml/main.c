#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Train a simple model

//Training Set
//Array of pairs of numbers 
//The 1st numbers is going to be the input of the model
//The 2nd One will be What we expect the model to output
float train[][2] = {
    {0, 0},
    {1, 2},
    {2, 4},
    {3, 6},
    {4, 8},
};//This is the training set

//1 000 000 000 000 => GPT-4
//1 => us

//y = x*w; Our model

#define train_count (sizeof(train) / sizeof(train[0]))


float rand_float(void){
    return (float) rand() / (float) RAND_MAX;
}

//Artificial Neuron
//As x1, x2, x3, ... our inputs and the biais b
//And w1, w2, w3, ... their respective weights
//y = x1*w1 + x2*w2 + x3*w3 + ... + b
//b the biais en francais la constante particuliere
//de la primitive d'une fonction: elle augmente la performance 

//The Cost Function, The Lost function etc...
float cost(float neural_input_weight, float biais) {
    //The square or the distance
    float result = 0.0f;

    for(size_t i = 0; i < train_count; ++i) {
        float x = train[i][0];
        float y = x*neural_input_weight + biais;
        //Having measure of the performance
        float distance = y - train[i][1];
        result += distance * distance;//Accumulator
        // printf("actual: %f, expected: %f\n", y, train[i][1]);
    }

    result /= train_count;
    return result;

}


int main(){
    //On initialise le depart de la suite
    // srand(time(NULL));
    srand(time(0));
    // srand(69);
    //Les aleatoires en C c'est une suite de la forme Un

    //It has roughly y = x*w; //w is the parameter
    float w = rand_float() * 10.0f;
    float b = rand_float() * 5.0f;

    float eps = 1e-3;
    float rate = 1e-3;


    //In Machine Learning People use learning rate
    printf("The Learning Rate %f\n", rate);
    printf("The First Cost %f\n", cost(w, b));
    size_t i = 0;
    do {
        float dw = (cost(w + eps, b) - cost(w, b))/eps;
        float db = (cost(w ,eps + b) - cost(w, b))/eps;
        w-=rate*dw;
        b-=rate*db;
        printf("cost = %f w = %f b= %f dw= %f db= %f\n", cost(w, b), w, b, dw, db);
        i++;
    }
    while (cost(w, b) > 0.001f && i <=632);

    printf("--------------------------\n");
    printf("The value of the Parameter w %f\n", w);
    printf("The value of the Biais b %f\n", b);
    

    return 0;
}