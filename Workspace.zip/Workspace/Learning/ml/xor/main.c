#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>


typedef struct {
    float or_w1;
    float or_w2;
    float or_b;
    
    float nand_w1;
    float nand_w2;
    float nand_b;
    
    float and_w1;
    float and_w2;
    float and_b;
    
} Xor;

float sigmoidf(float x) {
    return 1.f / (1.f + expf(-x));
}

//This function that given inputs x and y just basically
//feeds this x and y into the Neural Network and speeds out
// the final resut: This operation in NN is called forwarding
float forward(Xor model, float x1, float x2){
    float a = sigmoidf(model.or_w1 * x1 + model.or_w1 * x2 + model.or_b);
    float b = sigmoidf(model.nand_w1 * x1 + model.nand_w1 * x2 + model.nand_b);
    return sigmoidf(a * model.and_w1 + b * model.and_w2 + model.and_b);
}

typedef float train_sample[3];

//XOR-Gate
train_sample xor_train_set[]= {
    {0, 0, 0},
    {0, 1, 1},
    {1, 0, 1},
    {1, 1, 0}
};//The XOR Data Training Set


train_sample *train_set = xor_train_set;
// #define train_count (sizeof(train_set)/sizeof(train_set[0]))
size_t train_count = 4;
// #define cost_value cost(model)


float cost(Xor model) {
    //The square of the distance
    float result = 0.0f;

    for(size_t i = 0; i < train_count; ++i) {
        float x1 = train_set[i][0];
        float x2 = train_set[i][1];
        float y = forward(model, x1, x2);
        //Having measure of the performance
        float distance = y - train_set[i][2];
        result += distance * distance;//Accumulator
        // printf("actual: %f, expected: %f\n", y, train[i][1]);
    }

    

    result /= train_count;
    return result;

}

float rand_float(void){
    return (float) rand() / (float) RAND_MAX;
}

Xor rand_xor(void) {
    Xor m;
    m.or_w1 = rand_float();
    m.or_w2 = rand_float();
    m.or_b = rand_float();
    
    m.nand_w1 = rand_float();
    m.nand_w2 = rand_float();
    m.nand_b = rand_float();
    
    m.and_w1 = rand_float();
    m.and_w2 = rand_float();
    m.and_b = rand_float();
    
    return m;
}

void print_xor(Xor m) {
    printf("m.or_w1 = %f\n", m.or_w1);
    printf("m.or_w2  = %f\n", m.or_w2);
    printf("m.or_b  = %f\n", m.or_b);
    
    printf("m.nand_w1  = %f\n", m.nand_w1);
    printf("m.nand_w2 = %f\n", m.nand_w2);
    printf("m.nand_b = %f\n", m.nand_b);
    
    printf("m.and_w1  = %f\n", m.and_w1);
    printf("m.and_w2 = %f\n", m.and_w2);
    printf("m.and_b = %f\n", m.and_b);
}


#define delta_hyper_param_distance ((cost(m) - cost(saved_model))/eps)


//Function that accepts the actual model and output
// the gradient of the model
Xor finite_diff(Xor m, float eps, float rate) {
    // float dw1 = (cost(w1 + eps, w2, b) - cost_value) / eps;
    // float dw2 = (cost(w1, w2 + eps, b) - cost_value) / eps;
    // float db = (cost(w1, w2, eps + b) - cost_value) / eps;
    // w1 -= rate*dw1;
    // w2 -= rate*dw2;
    // b -= rate*db;

    Xor saved_model = m;
    Xor gradient_model = m;

    m.or_w1 += eps;
    // float or_dw1 = (cost(m) - cost(saved_model))/eps;
    gradient_model.or_w1 -= rate * delta_hyper_param_distance;
    m.or_w1 = saved_model.or_w1;

    
    m.or_w2 += eps;
    // float or_dw2 = (cost(m) - cost(saved_model))/eps;
    gradient_model.or_w2 -= rate * delta_hyper_param_distance;
    m.or_w2 = saved_model.or_w2;

    m.or_b += eps;
    // float or_db = (cost(m) - cost(saved_model))/eps;
    gradient_model.or_b -= rate * delta_hyper_param_distance;
    m.or_b = saved_model.or_b;

    m.nand_w1 += eps;
    // float nand_dw1 = (cost(m) - cost(saved_model))/eps;
    gradient_model.nand_w1 -= rate * delta_hyper_param_distance;
    m.nand_w1 = saved_model.nand_w1;

    m.nand_w2 += eps;
    // float nand_dw2 = (cost(m) - cost(saved_model))/eps;
    gradient_model.nand_w2 -= rate * delta_hyper_param_distance;
    m.nand_w2 = saved_model.nand_w1;

    m.nand_b += eps;
    // float nand_db = (cost(m) - cost(saved_model))/eps;
    gradient_model.nand_b -= rate * delta_hyper_param_distance;
    m.nand_b = saved_model.nand_b;

    m.and_w1 += eps;
    // float and_dw1 = (cost(m) - cost(saved_model))/eps;
    gradient_model.and_w1 -= rate * delta_hyper_param_distance;
    m.and_w1 = saved_model.and_w1;

    m.and_w2 += eps;
    // float and_dw2 = (cost(m) - cost(saved_model))/eps;
    gradient_model.and_w2 -= rate * delta_hyper_param_distance;
    m.and_w2 = saved_model.and_w2;

    m.and_b += eps;
    // float and_db = (cost(m) - cost(saved_model))/eps;
    gradient_model.and_b -= rate * delta_hyper_param_distance;
    m.and_b = saved_model.and_b;

    return gradient_model;

}

int main(void){
    srand(60);
    Xor model = rand_xor();
    print_xor(model);
    float eps = 1e-5;//Le plus petit bit-float
    float rate = 31.f;//C'est le plus grand bit-float



    // Tunning Function
    for(size_t i = 0; i< 7000000; ++i){
        // float cost_value = cost(w1,w2);
        // printf("w1 = %f w2 = %f cost = %f b = %f\n", w1, w2, cost_value, b);
        // printf("%f\n", cost_value);
        
        model = finite_diff(model, eps, rate);
        // printf("----------------\n");
        // print_xor(model);
    }
    printf("---------------\n");
    print_xor(model);
    printf("---------------\n");

    
    for (size_t i=0; i<2; ++i){
        for(size_t j=0; j<2; ++j){
            printf("%zu GATE %zu = %f\n", i, j, forward(model, i, j));
        }
    }
}