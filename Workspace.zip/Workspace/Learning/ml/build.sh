#!/bin/sh

set -xe

clang -Wall -Wextra -o main main.c
clang -Wall -Wextra -o one-input-and-byte/main ./one-input-and-byte/main.c
clang -Wall -Wextra -o one-single-input/main ./one-single-input/main.c
clang -Wall -Wextra -o gates/main ./gates/main.c -lm
clang -Wall -Wextra -o xor/main ./xor/main.c -lm