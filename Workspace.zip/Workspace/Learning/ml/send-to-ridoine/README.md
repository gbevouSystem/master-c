# 😂😂 FAIRE UN CRUD AVEC LES TENSEURS EN C
## LE PROBLEME INITIAL C'EST D'ESSAYER DE CREER UN SORTE DE BIBLIOTEQUE POUR GERER EFFICACEMENT LES TENSEURS EN C
### SITUATION
Je suppose que tu es habitue avec le ML
C'est un reseau de neurone de 3 neurones en 2 perceptrons.

J'ai un structure de donnees representant un vecteur d'un model dont les proprietes sont de type float (nombre a virgule code sur 4 octets 32bits).

Dans la recherche du vecteur qui minimise ma fonction de perte ou de cout(dans mon cas)
Je suis entrain de calculer la ou une sorte de derivee de ma fonction f de cout serait null
La formule math c'est derivee_de_f(a) = lim de (f(x+a) - f(x))/a quand a tend vers 0. Et je dois trouver le x pour le quel c'est null pour minimiser le cout. Tout ceci est continue mais l'informatique est discrete.

Une forme discrete de trouver quand la derivee est nulle c'est prendre un valeur arbitraire a = 1/100_000(ceci est le plus petit flottant en C). Ensuite de boucler en modifiant a chaque fois x pour trouver la valeur de x ou l'expression (fonction_de_cout(x + a) - f(x)) / a   est nulle.



Le probleme est que x peut etre n'importe quoi en algebre: Un tenseur de dimension 0(comme une simple valeur par exemple 3), de dimension 1(un vecteur), dimension 2(une matrice) ainsi de suite.

Hors dans mon cas x est un vecteur. Je devrais modifier un a un chaque propriete de mon vecteur.


### Voici ce que j'ai fait: ===========


C'est un programme pour creer un neural network de 9 parametres a 2 perceptrons.
Pour modeliser sur 1bit les portes logiques de la forme 

//LA PORTE XOR
0 XOR 0 = 0\
0 XOR 1 = 1\
1 XOR 0 = 1\
1 XOR 1 = 0

//LA PORTE INVERSE_XOR
0 INVERSE_XOR 0 = 1\
0 INVERSE_XOR 1 = 0\
1 INVERSE_XOR 0 = 0\
1 INVERSE_XOR 1 = 1

//
0 XOR 0 = 1\
0 XOR 1 = 1\
1 XOR 0 = 0\
1 XOR 1 = 0

//
0 XOR 0 = 0\
0 XOR 1 = 0\
1 XOR 0 = 1\
1 XOR 1 = 1

//
0 XOR 0 = 0\
0 XOR 1 = 1\
1 XOR 0 = 0\
1 XOR 1 = 1

//
0 XOR 0 = 1\
0 XOR 1 = 0\
1 XOR 0 = 1\
1 XOR 1 = 0


### Pour executer le fichier sur linux Tu devrais
- cloner ce repo et naviguer dans le root du clone
- executer la commande ./build.sh && ./main dans ton terminal


Si tu veux executer la seconde fonction,
- Commente la Premiere fonction
- Decommente la Seconde Fonction
- Puis re-execute la commande ./build.sh && ./main

### En sortie 