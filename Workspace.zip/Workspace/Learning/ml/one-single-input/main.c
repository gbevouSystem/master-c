#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Train a simple model

//Training Set
//Array of pairs of numbers 
//The 1st numbers is going to be the input of the model
//The 2nd One will be What we expect the model to output
float train[][2] = {
    {0, 0},
    {1, 2},
    {2, 4},
    {3, 6},
    {4, 8},
};//This is the training set

//1 000 000 000 000 => GPT-4
//1 => us

//y = x*w; Our model

#define train_count (sizeof(train) / sizeof(train[0]))


float rand_float(void){
    return (float) rand() / (float) RAND_MAX;
}

//The Cost Function, The Lost function etc...
float cost(float model) {
    //The square or the distance
    float result = 0.0f;

    for(size_t i = 0; i < train_count; ++i) {
        float x = train[i][0];
        float y = x*model;
        //Having measure of the performance
        float distance = y - train[i][1];
        result += distance * distance;//Accumulator
        // printf("actual: %f, expected: %f\n", y, train[i][1]);
    }

    result /= train_count;
    return result;

}


int main(){
    //On initialise le depart de la suite
    // srand(time(NULL));
    srand(time(0));
    // srand(69);
    //Les aleatoires en C c'est une suite de la forme Un

    //It has roughly y = x*w; //w is the parameter
    float w = rand_float() * 10.0f;

    float eps = 1e-3;
    float rate = 1e-3;



    //In Machine Learning People use learning rate
    printf("The Rate %f\n", rate);
    printf("The First Cost %f\n", cost(w));
    size_t i = 0;
    do {
        float dcost = (cost(w + eps) - cost(w))/eps;
        w-=rate*dcost;
        printf("cost = %f w = %f\n", cost(w), w);
        i++;
    }
    while (cost(w) >= 0 && i <=627);

    printf("--------------------------\n");
    printf("The value of the Parameter w %f\n", w);
    

    return 0;
}