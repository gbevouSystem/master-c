#if !defined(__PLAYER_H__)
	#define __PLAYER_H__

	typedef struct Player {
		char name[26];
		int level;
	}Player;

	Player create(void);
	void say(Player p, char *message);

#endif
