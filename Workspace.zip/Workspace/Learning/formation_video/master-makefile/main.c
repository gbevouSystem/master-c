#include "player.h"
#include <stdio.h>

int main(void) {
	Player p1 = create();
	say(p1, "Bonjour");
	
	return 0;
}
