const fs = require('fs');

function unicodeParser(langCountry, unicodeRange) {
    const ranges = unicodeRange.split(', ');

    const data = {
        [langCountry]: [],
    };

    const returnData = []

    ranges.forEach((range) => {
        const unicodeCharRange = range.substring(2);
        const [start, end] = unicodeCharRange.split('-');
        const unicodeChars = [];

        for (let i = parseInt(start, 16); i <= parseInt(end, 16); i++) {


            unicodeChars.push({
                unicodeChar: `U+${i.toString(16).toUpperCase()}`,
                description: "",
            });

            returnData.push(i)
        }

        data[langCountry] = data[langCountry].concat(unicodeChars);
    });

    const jsonData = JSON.stringify(data, null, 2);

    fs.writeFile(`${langCountry}.json`, jsonData, (err) => {
        if (err) {
            console.error('Erreur lors de l\'écriture du fichier JSON :', err);
        } else {
            console.log(`Fichier JSON généré avec succès sous le nom : ${langCountry}.json`);
        }
    });
    return returnData
}


function allChars(...languages) {
    const mergedData = {};
    languages.forEach((languageData) => {
        for (const lang in languageData) {
            if (mergedData[lang]) {
                mergedData[lang] = [...new Set(mergedData[lang].concat(languageData[lang]))];
            } else {
                mergedData[lang] = languageData[lang];
            }
        }
    });

    const jsonData = JSON.stringify(mergedData, null, 2);

    fs.writeFile('output.json', jsonData, (err) => {
        if (err) {
            console.error('Erreur lors de l\'écriture du fichier JSON :', err);
        } else {
            console.log('Fichier JSON généré avec succès.');
        }
    });
}

// Exemple d'utilisation des fonctions avec différentes chaînes unicodeRange
const langCountryFR = "fr_FR";
const langCountryEN = "en_US";
const langCountryEWE = "ew_TG";

const unicodeRangeInputFR = "U+20-5F, U+61-7A, U+7C, U+A0, U+A7, U+A9, U+AB, U+B2-B3, U+BB, U+C0, U+C2, U+C6-CB, U+CE-CF, U+D4, U+D9, U+DB-DC, U+E0, U+E2, U+E6-EB, U+EE-EF, U+F4, U+F9, U+FB-FC, U+FF, U+152-153, U+178, U+2B3, U+2E2, U+1D48-1D49, U+2010-2011, U+2013-2014, U+2019, U+201C-201D, U+2020-2021, U+2026, U+202F-2030, U+20AC, U+2212"
const unicodeRangeInputEN = "U+20-5F, U+61-7A, U+7C, U+A0, U+A7, U+A9, U+AB, U+B2-B3, U+BB, U+C0, U+C2, U+C6-CB, U+CE-CF, U+D4, U+D9, U+DB-DC, U+E0, U+E2, U+E6-EB, U+EE-EF, U+F4, U+F9, U+FB-FC, U+FF, U+152-153, U+178, U+2B3, U+2E2, U+1D48-1D49, U+2010-2011, U+2013-2014, U+2019, U+201C-201D, U+2020-2021, U+2026, U+202F-2030, U+20AC, U+2212"
const unicodeRangeInputEWE = "U+20-42, U+44-49, U+4B-50, U+52-5F, U+61-62, U+64-69, U+6B-70, U+72-7D, U+A0, U+A7, U+A9, U+C0-C1, U+C3, U+C8-C9, U+CC-CD, U+D2-D3, U+D5, U+D9-DA, U+E0-E1, U+E3, U+E8-E9, U+EC-ED, U+F2-F3, U+F5, U+F9-FA, U+128-129, U+14A-14B, U+168-169, U+186, U+189, U+190-192, U+194, U+1B2, U+254, U+256, U+25B, U+263, U+28B, U+300-301, U+303, U+1EBC-1EBD, U+2010-2011, U+2013-2014, U+2018-2019, U+201C-201D, U+2020-2021, U+2026, U+2030, U+2032-2033, U+20AC"
const dataFR = unicodeParser(langCountryFR, unicodeRangeInputFR);
const dataEN = unicodeParser(langCountryEN, unicodeRangeInputEN);
const dataEWE = unicodeParser(langCountryEWE, unicodeRangeInputEWE);

allChars(dataFR, dataEN, dataEWE);









